# knnring
Implementation of knn in mpi
